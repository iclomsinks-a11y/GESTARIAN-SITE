export type EstadoExpediente = 
  | 'RECEPCION' 
  | 'DIAGNOSTICO' 
  | 'EN_REPARACION' 
  | 'ESPERA_PIEZAS' 
  | 'CONTROL_CALIDAD' 
  | 'LISTO' 
  | 'ENTREGADO';

export interface FotoEvolucion {
  id: string;
  titulo: string;
  fase: string;
  fecha: string;
  hora: string;
  url: string;
  descripcion: string;
  observacionesMecanico?: string;
}

export interface ConceptoPresupuesto {
  id: string;
  descripcion: string;
  cantidad: number;
  precioUnitario: number;
  total: number;
  tipo: 'RECAMBIO' | 'MANO_OBRA' | 'GESTION';
}

export interface PresupuestoCliente {
  id: string;
  numero: string;
  fecha: string;
  validoHasta: string;
  estado: 'PENDIENTE_FIRMA' | 'APROBADO' | 'RECHAZADO';
  fechaAprobacion?: string;
  firmaHash?: string;
  firmanteNombre?: string;
  firmanteDni?: string;
  conceptos: ConceptoPresupuesto[];
  baseImponible: number;
  ivaPorcentaje: number;
  ivaImporte: number;
  total: number;
}

export interface FacturaCliente {
  id: string;
  numero: string;
  fechaEmision: string;
  fechaVencimiento: string;
  estadoPago: 'PAGADA' | 'PENDIENTE';
  metodoPago: string;
  baseImponible: number;
  ivaPorcentaje: number;
  ivaImporte: number;
  total: number;
  conceptoPrincipal: string;
}

export interface ExpedienteCliente {
  id: string;
  codigoExpediente: string;
  matricula: string;
  marcaModelo: string;
  kilometros: number;
  color: string;
  anoFabricacion?: number;
  fechaEntrada: string;
  fechaEstimadaEntrega: string;
  estado: EstadoExpediente;
  porcentajeProgreso: number;
  mecanicoAsignado: string;
  trabajosPrincipales: string[];
  fotosEvolucion: FotoEvolucion[];
  presupuestos: PresupuestoCliente[];
  facturas: FacturaCliente[];
}

export interface ClienteSesion {
  dni: string;
  email: string;
  nombreRazonSocial: string;
  telefono: string;
  direccion: string;
  tallerAsignado: {
    nombre: string;
    cif: string;
    direccion: string;
    telefono: string;
    whatsapp: string;
    email: string;
  };
  expedientes: ExpedienteCliente[];
}

export interface SolicitudCita {
  id: string;
  fechaDeseada: string;
  horarioPreferente: 'MANANA' | 'TARDE';
  tipoServicio: string;
  observaciones: string;
  estado: 'SOLICITADA' | 'CONFIRMADA';
}
