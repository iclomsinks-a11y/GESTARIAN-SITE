import React from 'react';
import { ClienteSesion } from '../types';
import { X, Phone, MessageSquare, MapPin, Mail, Clock, ExternalLink } from 'lucide-react';

interface ModalContactoProps {
  taller: ClienteSesion['tallerAsignado'];
  matricula: string;
  onCerrar: () => void;
}

export const ModalContacto: React.FC<ModalContactoProps> = ({
  taller,
  matricula,
  onCerrar
}) => {
  const whatsappUrl = `https://wa.me/${taller.whatsapp}?text=${encodeURIComponent(
    `Hola, soy cliente de Gestarian respecto al vehículo con matrícula ${matricula}. Quería realizar una consulta.`
  )}`;

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${taller.nombre} ${taller.direccion}`
  )}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0e1424] border border-white/10 rounded-2xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative">
        <button
          onClick={onCerrar}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Contacto con el Taller</h3>
            <p className="text-xs text-slate-400">{taller.nombre}</p>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed mb-6">
          Comunícate directamente con los asesores periciales y mecánicos a cargo de tu expediente.
        </p>

        <div className="space-y-3 mb-6">
          {/* Botón WhatsApp */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between p-3.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 transition-all group"
          >
            <div className="flex items-center gap-3">
              <MessageSquare className="w-5 h-5 text-emerald-400" />
              <div className="text-left text-xs">
                <div className="font-bold text-white">Chat Directo por WhatsApp</div>
                <div className="text-emerald-400/80">Respuesta inmediata</div>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 opacity-70 group-hover:opacity-100" />
          </a>

          {/* Botón Llamada Telefónica */}
          <a
            href={`tel:${taller.telefono}`}
            className="flex items-center justify-between p-3.5 rounded-xl bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 text-sky-300 transition-all group"
          >
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-sky-400" />
              <div className="text-left text-xs">
                <div className="font-bold text-white">Llamar a Recepción</div>
                <div className="text-sky-400/80 font-mono">{taller.telefono}</div>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 opacity-70 group-hover:opacity-100" />
          </a>

          {/* Ubicación Google Maps */}
          <a
            href={mapsUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between p-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 transition-all group"
          >
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-purple-400" />
              <div className="text-left text-xs">
                <div className="font-bold text-white">Cómo Llegar (Google Maps)</div>
                <div className="text-slate-400 text-[11px] truncate max-w-[200px]">{taller.direccion}</div>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 opacity-70 group-hover:opacity-100" />
          </a>
        </div>

        <div className="p-3 bg-white/[0.02] border border-white/5 rounded-xl text-center text-[11px] text-slate-400 flex items-center justify-center gap-2">
          <Clock className="w-3.5 h-3.5 text-slate-500" />
          <span>Horario de atención: Lunes a Viernes de 08:30 a 19:30</span>
        </div>
      </div>
    </div>
  );
};
