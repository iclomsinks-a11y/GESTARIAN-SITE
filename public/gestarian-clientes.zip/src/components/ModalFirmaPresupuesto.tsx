import React, { useState, useRef, useEffect } from 'react';
import { PresupuestoCliente, ClienteSesion } from '../types';
import { ShieldCheck, X, Check, RotateCcw, Lock } from 'lucide-react';

interface ModalFirmaPresupuestoProps {
  presupuesto: PresupuestoCliente;
  cliente: ClienteSesion;
  onConfirmar: (presupuestoId: string, firmaHash: string) => void;
  onCerrar: () => void;
}

export const ModalFirmaPresupuesto: React.FC<ModalFirmaPresupuestoProps> = ({
  presupuesto,
  cliente,
  onConfirmar,
  onCerrar
}) => {
  const [aceptaCondiciones, setAceptaCondiciones] = useState(false);
  const [firmando, setFirmando] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawing = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }, []);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    isDrawing.current = true;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setHasDrawn(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    isDrawing.current = false;
  };

  const limpiarFirma = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
  };

  const handleFirmarAprobar = () => {
    if (!aceptaCondiciones) {
      alert('Debes marcar la casilla de aceptación y conformidad con los trabajos.');
      return;
    }

    setFirmando(true);
    setTimeout(() => {
      const randomHash = 'GEST-FIRMA-' + Math.random().toString(36).substring(2, 8).toUpperCase() + '-' + Date.now().toString().slice(-4);
      onConfirmar(presupuesto.id, randomHash);
      setFirmando(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0e1424] border border-white/10 rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative my-8">
        <button
          onClick={onCerrar}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 text-emerald-400 mb-2">
          <ShieldCheck className="w-6 h-6" />
          <span className="text-xs uppercase font-bold tracking-wider">Firma Digital Telemática</span>
        </div>

        <h3 className="text-xl font-bold text-white mb-1">
          Aprobación del Presupuesto {presupuesto.numero}
        </h3>
        <p className="text-xs text-slate-400 mb-6">
          Al confirmar, autorizas al taller a dar inicio a los trabajos mecánicos descritos por un importe total de <strong className="text-white font-mono">{presupuesto.total.toFixed(2)} €</strong>.
        </p>

        {/* Datos del firmante */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-3.5 mb-5 text-xs space-y-1">
          <div className="flex justify-between">
            <span className="text-slate-400">Titular / Empresa:</span>
            <span className="font-semibold text-white">{cliente.nombreRazonSocial}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">DNI / CIF:</span>
            <span className="font-mono text-white">{cliente.dni}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Fecha y Hora:</span>
            <span className="text-slate-300">{new Date().toLocaleString('es-ES')}</span>
          </div>
        </div>

        {/* Lienzo de Firma */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs uppercase font-bold tracking-wider text-slate-300">
              Dibuja tu firma en el recuadro:
            </label>
            {hasDrawn && (
              <button
                type="button"
                onClick={limpiarFirma}
                className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Borrar</span>
              </button>
            )}
          </div>

          <div className="border border-white/15 rounded-xl bg-slate-950/80 overflow-hidden relative touch-none">
            <canvas
              ref={canvasRef}
              width={420}
              height={150}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
              className="w-full h-36 cursor-crosshair block"
            />
            {!hasDrawn && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-slate-600 text-xs italic">
                Firma aquí con el dedo o ratón
              </div>
            )}
          </div>
        </div>

        {/* Checkbox de Conformidad */}
        <label className="flex items-start gap-3 p-3 bg-white/[0.02] border border-white/10 rounded-xl cursor-pointer hover:bg-white/[0.04] transition-colors mb-6">
          <input
            type="checkbox"
            checked={aceptaCondiciones}
            onChange={(e) => setAceptaCondiciones(e.target.checked)}
            className="mt-0.5 rounded border-slate-700 text-emerald-500 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
          />
          <span className="text-xs text-slate-300 leading-relaxed">
            Doy mi expresa conformidad con el presupuesto, autorizando la reparación, recambios y mano de obra detallados, con validez de firma electrónica.
          </span>
        </label>

        {/* Botones */}
        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCerrar}
            className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold cursor-pointer"
          >
            Cancelar
          </button>

          <button
            type="button"
            disabled={!aceptaCondiciones || firmando}
            onClick={handleFirmarAprobar}
            className={`px-6 py-2.5 rounded-xl text-white text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              aceptaCondiciones && !firmando
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 shadow-lg shadow-emerald-500/25 active:scale-[0.99]'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>{firmando ? 'Sellando telemáticamente...' : 'Firmar y Autorizar Reparación'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
