import React from 'react';
import { FotoEvolucion } from '../types';
import { Camera, Eye, Calendar, Clock, MessageSquare, Maximize2 } from 'lucide-react';

interface GaleriaEvolucionProps {
  fotos: FotoEvolucion[];
  onSeleccionarFoto: (foto: FotoEvolucion) => void;
}

export const GaleriaEvolucion: React.FC<GaleriaEvolucionProps> = ({
  fotos,
  onSeleccionarFoto
}) => {
  if (fotos.length === 0) {
    return (
      <div className="bg-[#0e1424] border border-white/10 rounded-2xl p-8 text-center">
        <Camera className="w-10 h-10 text-slate-500 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white mb-1">Sin capturas fotográficas aún</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          El equipo del taller subirá fotografías de las diferentes fases a medida que se ejecuten los trabajos en tu vehículo.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Camera className="w-5 h-5 text-purple-400" />
            <span>Evolución Audiovisual del Vehículo</span>
          </h3>
          <p className="text-xs text-slate-400">
            Transparencia total: capturas periciales subidas en directo por el taller durante el proceso de reparación.
          </p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/20">
          {fotos.length} fotos documentadas
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {fotos.map((foto) => (
          <div
            key={foto.id}
            onClick={() => onSeleccionarFoto(foto)}
            className="group bg-[#0e1424] border border-white/10 hover:border-purple-500/40 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/10 cursor-pointer flex flex-col"
          >
            {/* Contenedor de la foto */}
            <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
              <img
                src={foto.url}
                alt={foto.titulo}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 group-hover:opacity-90 transition-opacity"></div>
              
              {/* Badge de la fase */}
              <div className="absolute top-3 left-3 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] font-bold text-white border border-white/10">
                {foto.fase}
              </div>

              {/* Botón de Zoom */}
              <div className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <Maximize2 className="w-4 h-4" />
              </div>

              {/* Fecha y hora */}
              <div className="absolute bottom-3 left-3 text-[11px] text-slate-300 flex items-center gap-2">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {foto.fecha}
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {foto.hora}
                </span>
              </div>
            </div>

            {/* Datos y comentarios */}
            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <h4 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors mb-1">
                  {foto.titulo}
                </h4>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {foto.descripcion}
                </p>
              </div>

              {foto.observacionesMecanico && (
                <div className="mt-3 pt-3 border-t border-white/5 flex items-start gap-2 text-[11px] text-slate-300 bg-white/[0.02] p-2 rounded-lg">
                  <MessageSquare className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />
                  <span className="italic">{foto.observacionesMecanico}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
