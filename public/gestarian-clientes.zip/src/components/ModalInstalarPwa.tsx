import React from 'react';
import { X, Smartphone, Monitor, Download, Share2, PlusSquare } from 'lucide-react';

interface ModalInstalarPwaProps {
  onCerrar: () => void;
}

export const ModalInstalarPwa: React.FC<ModalInstalarPwaProps> = ({ onCerrar }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0e1424] border border-white/10 rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative">
        <button
          onClick={onCerrar}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-500 to-purple-600 flex items-center justify-center font-bold text-white text-lg mx-auto mb-3 shadow-lg shadow-sky-500/20">
            G
          </div>
          <h3 className="text-xl font-bold text-white mb-1">
            Instalar Portal de Clientes
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Accede al seguimiento de tu coche directamente desde tu pantalla de inicio como una aplicación nativa, sin descargas pesadas.
          </p>
        </div>

        <div className="space-y-4 mb-6">
          {/* iOS / iPhone */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-2.5 text-xs font-bold text-sky-400 mb-1.5">
              <Smartphone className="w-4 h-4" />
              <span>En iPhone o iPad (Safari)</span>
            </div>
            <ol className="text-xs text-slate-300 space-y-1 list-decimal list-inside leading-relaxed pl-1">
              <li>Pulsa el botón de <strong>Compartir</strong> <Share2 className="w-3.5 h-3.5 inline mx-0.5" /> en la barra inferior de Safari.</li>
              <li>Desliza hacia abajo y pulsa en <strong>"Añadir a pantalla de inicio"</strong> <PlusSquare className="w-3.5 h-3.5 inline mx-0.5" />.</li>
              <li>Pulsa <strong>"Añadir"</strong> arriba a la derecha.</li>
            </ol>
          </div>

          {/* Android */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-2.5 text-xs font-bold text-emerald-400 mb-1.5">
              <Smartphone className="w-4 h-4" />
              <span>En Android (Chrome / Samsung Internet)</span>
            </div>
            <ol className="text-xs text-slate-300 space-y-1 list-decimal list-inside leading-relaxed pl-1">
              <li>Pulsa en el menú de los <strong>tres puntos ⋮</strong> arriba a la derecha.</li>
              <li>Selecciona <strong>"Instalar aplicación"</strong> o <strong>"Añadir a pantalla de inicio"</strong>.</li>
            </ol>
          </div>

          {/* PC / Mac */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-2.5 text-xs font-bold text-purple-400 mb-1.5">
              <Monitor className="w-4 h-4" />
              <span>En Ordenador (Chrome / Edge)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Haz clic en el icono <strong>⊕ Instalar</strong> que verás a la derecha de la barra de direcciones del navegador.
            </p>
          </div>
        </div>

        <button
          onClick={onCerrar}
          className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs transition-colors cursor-pointer"
        >
          Entendido
        </button>
      </div>
    </div>
  );
};
