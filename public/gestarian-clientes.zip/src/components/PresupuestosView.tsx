import React from 'react';
import { PresupuestoCliente } from '../types';
import { FileText, CheckCircle2, Clock, Download, Check, AlertCircle, Wrench, ShieldCheck } from 'lucide-react';

interface PresupuestosViewProps {
  presupuestos: PresupuestoCliente[];
  onAbrirFirma: (presupuesto: PresupuestoCliente) => void;
  onDescargarPdf: (presupuesto: PresupuestoCliente) => void;
}

export const PresupuestosView: React.FC<PresupuestosViewProps> = ({
  presupuestos,
  onAbrirFirma,
  onDescargarPdf
}) => {
  if (presupuestos.length === 0) {
    return (
      <div className="bg-[#0e1424] border border-white/10 rounded-2xl p-8 text-center">
        <FileText className="w-10 h-10 text-slate-500 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white mb-1">No hay presupuestos emitidos</h3>
        <p className="text-xs text-slate-400">
          En cuanto el taller valore los trabajos de este expediente, aparecerá aquí tu presupuesto detallado.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <FileText className="w-5 h-5 text-sky-400" />
          <span>Presupuestos y Órdenes de Trabajo</span>
        </h3>
        <p className="text-xs text-slate-400">
          Revisa el desglose de piezas y mano de obra. Puedes firmar y dar tu conformidad de forma telemática con plena validez.
        </p>
      </div>

      <div className="space-y-6">
        {presupuestos.map((pre) => {
          const isAprobado = pre.estado === 'APROBADO';
          const isPendiente = pre.estado === 'PENDIENTE_FIRMA';

          return (
            <div
              key={pre.id}
              className={`bg-[#0e1424] border rounded-2xl p-6 lg:p-8 transition-all shadow-xl ${
                isPendiente
                  ? 'border-amber-500/40 bg-gradient-to-b from-[#0e1424] to-[#121626]'
                  : 'border-white/10'
              }`}
            >
              {/* Encabezado del Presupuesto */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-xs px-2.5 py-0.5 rounded bg-white/10 text-slate-200 font-bold">
                      {pre.numero}
                    </span>
                    <span className="text-xs text-slate-400">
                      Fecha: {pre.fecha} · Válido hasta: {pre.validoHasta}
                    </span>
                  </div>
                  <h4 className="text-lg font-bold text-white">
                    Presupuesto Oficial de Reparación
                  </h4>
                </div>

                <div className="flex items-center gap-2">
                  {isAprobado ? (
                    <span className="px-3 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>Aprobado por el Cliente</span>
                    </span>
                  ) : (
                    <span className="px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1.5 animate-pulse">
                      <Clock className="w-4 h-4 text-amber-400" />
                      <span>Pendiente de tu Conformidad</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Tabla Desglosada de Conceptos */}
              <div className="mt-6 overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-white/10 text-slate-400 uppercase font-semibold">
                      <th className="pb-3 pl-2">Concepto / Referencia</th>
                      <th className="pb-3 text-center">Tipo</th>
                      <th className="pb-3 text-center">Uds / Horas</th>
                      <th className="pb-3 text-right">P. Unitario</th>
                      <th className="pb-3 pr-2 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {pre.conceptos.map((item) => (
                      <tr key={item.id} className="hover:bg-white/[0.02]">
                        <td className="py-3 pl-2 font-medium text-slate-200">
                          {item.descripcion}
                        </td>
                        <td className="py-3 text-center">
                          <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                            item.tipo === 'RECAMBIO'
                              ? 'bg-sky-500/10 text-sky-300'
                              : item.tipo === 'MANO_OBRA'
                              ? 'bg-purple-500/10 text-purple-300'
                              : 'bg-slate-500/10 text-slate-300'
                          }`}>
                            {item.tipo}
                          </span>
                        </td>
                        <td className="py-3 text-center font-mono text-slate-300">
                          {item.cantidad}
                        </td>
                        <td className="py-3 text-right font-mono text-slate-300">
                          {item.precioUnitario.toFixed(2)} €
                        </td>
                        <td className="py-3 pr-2 text-right font-mono font-bold text-white">
                          {item.total.toFixed(2)} €
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Totales y Liquidación */}
              <div className="mt-6 pt-6 border-t border-white/10 flex flex-col md:flex-row items-start md:items-end justify-between gap-6">
                <div>
                  {isAprobado && pre.firmaHash && (
                    <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 max-w-sm">
                      <div className="flex items-center gap-2 text-xs font-bold text-emerald-300 mb-0.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        <span>Sellado y Firmado Telemáticamente</span>
                      </div>
                      <div className="text-[11px] text-slate-300">
                        Firmante: <strong>{pre.firmanteNombre} ({pre.firmanteDni})</strong>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Hash Firma: {pre.firmaHash} · {pre.fechaAprobacion}
                      </div>
                    </div>
                  )}
                </div>

                <div className="w-full md:w-64 space-y-1.5 text-xs text-right">
                  <div className="flex justify-between text-slate-400">
                    <span>Base Imponible:</span>
                    <span className="font-mono text-slate-200">{pre.baseImponible.toFixed(2)} €</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>IVA ({pre.ivaPorcentaje}%):</span>
                    <span className="font-mono text-slate-200">{pre.ivaImporte.toFixed(2)} €</span>
                  </div>
                  <div className="flex justify-between text-base font-bold text-white pt-2 border-t border-white/10">
                    <span>TOTAL PRESUPUESTO:</span>
                    <span className="font-mono text-sky-400 text-lg">{pre.total.toFixed(2)} €</span>
                  </div>
                </div>
              </div>

              {/* Acciones */}
              <div className="mt-6 pt-6 border-t border-white/10 flex flex-wrap items-center justify-end gap-3">
                <button
                  onClick={() => onDescargarPdf(pre)}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Descargar Copia Oficial PDF</span>
                </button>

                {isPendiente && (
                  <button
                    onClick={() => onAbrirFirma(pre)}
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-[0.99] transition-all cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>Aprobar Presupuesto con Firma Digital</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
