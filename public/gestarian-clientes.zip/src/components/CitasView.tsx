import React, { useState } from 'react';
import { Calendar, Clock, CheckCircle2, Car, MessageSquare, Send } from 'lucide-react';

interface CitasViewProps {
  matricula: string;
  marcaModelo: string;
  onSolicitudEnviada: (servicio: string, fecha: string) => void;
}

export const CitasView: React.FC<CitasViewProps> = ({
  matricula,
  marcaModelo,
  onSolicitudEnviada
}) => {
  const [servicio, setServicio] = useState('Mantenimiento y Cambio de Aceite');
  const [fecha, setFecha] = useState('');
  const [franja, setFranja] = useState('MANANA');
  const [comentarios, setComentarios] = useState('');
  const [enviado, setEnviado] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fecha) {
      alert('Por favor selecciona una fecha preferente.');
      return;
    }
    setEnviado(true);
    onSolicitudEnviada(servicio, fecha);
  };

  if (enviado) {
    return (
      <div className="bg-[#0e1424] border border-emerald-500/30 rounded-2xl p-8 text-center max-w-lg mx-auto">
        <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-4 border border-emerald-500/40">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-white mb-2">¡Solicitud de Cita Recibida!</h3>
        <p className="text-xs text-slate-300 leading-relaxed mb-6">
          Hemos comunicado tu petición al equipo de recepción técnica de Gestarian para el vehículo <strong>{matricula}</strong>. Recibirás una confirmación por WhatsApp en breve.
        </p>
        <button
          onClick={() => setEnviado(false)}
          className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold cursor-pointer"
        >
          Solicitar otra cita
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Calendar className="w-5 h-5 text-sky-400" />
          <span>Solicitar Cita de Taller o Revisión</span>
        </h3>
        <p className="text-xs text-slate-400">
          Reserva día para tu próximo mantenimiento, inspección técnica previa a ITV o revisión de avería.
        </p>
      </div>

      <div className="bg-[#0e1424] border border-white/10 rounded-2xl p-6 lg:p-8">
        <div className="flex items-center gap-3 p-3.5 bg-white/5 rounded-xl mb-6 border border-white/5">
          <Car className="w-5 h-5 text-sky-400" />
          <div className="text-xs">
            <div className="font-bold text-white">{marcaModelo}</div>
            <div className="text-slate-400 font-mono">Matrícula: {matricula}</div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-300 font-semibold mb-2">
              Tipo de Servicio Requerido
            </label>
            <select
              value={servicio}
              onChange={(e) => setServicio(e.target.value)}
              className="w-full text-xs p-3.5 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-sky-400 cursor-pointer"
            >
              <option value="Mantenimiento Periódico (Aceite y Filtros)" className="bg-slate-900">Mantenimiento Periódico (Aceite y Filtros)</option>
              <option value="Revisión Pre-ITV Completa" className="bg-slate-900">Revisión Pre-ITV Completa</option>
              <option value="Frenos (Pastillas / Discos)" className="bg-slate-900">Frenos (Pastillas / Discos)</option>
              <option value="Neumáticos y Paralelo Láser" className="bg-slate-900">Neumáticos y Paralelo Láser</option>
              <option value="Diagnosis Electrónica / Testigo Motor" className="bg-slate-900">Diagnosis Electrónica / Testigo Motor</option>
              <option value="Climatización y Carga de Gas" className="bg-slate-900">Climatización y Carga de Gas</option>
              <option value="Otra intervención mecánica" className="bg-slate-900">Otra intervención mecánica</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs uppercase tracking-wider text-slate-300 font-semibold mb-2">
                Fecha Preferente *
              </label>
              <input
                type="date"
                value={fecha}
                onChange={(e) => setFecha(e.target.value)}
                className="w-full text-xs p-3.5 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-sky-400"
                required
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-slate-300 font-semibold mb-2">
                Franja Horaria Preferente
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setFranja('MANANA')}
                  className={`p-3 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                    franja === 'MANANA'
                      ? 'bg-sky-500/20 border-sky-400 text-sky-300'
                      : 'bg-white/5 border-white/10 text-slate-400'
                  }`}
                >
                  Mañana (08:30 - 13:30)
                </button>
                <button
                  type="button"
                  onClick={() => setFranja('TARDE')}
                  className={`p-3 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                    franja === 'TARDE'
                      ? 'bg-sky-500/20 border-sky-400 text-sky-300'
                      : 'bg-white/5 border-white/10 text-slate-400'
                  }`}
                >
                  Tarde (15:30 - 19:30)
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-300 font-semibold mb-2">
              Observaciones o Síntomas Detectados (Opcional)
            </label>
            <textarea
              rows={3}
              placeholder="Indica cualquier detalle, ruidos extraños o petición especial..."
              value={comentarios}
              onChange={(e) => setComentarios(e.target.value)}
              className="w-full text-xs p-3.5 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-sky-400 resize-none"
            ></textarea>
          </div>

          <button
            type="submit"
            className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20 active:scale-[0.99] transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Enviar Solicitud al Taller</span>
          </button>
        </form>
      </div>
    </div>
  );
};
