import React from 'react';
import { ExpedienteCliente, EstadoExpediente } from '../types';
import { 
  CheckCircle2, 
  Clock, 
  Wrench, 
  Search, 
  ShieldCheck, 
  Sparkles, 
  Calendar, 
  User, 
  AlertCircle,
  FileText
} from 'lucide-react';

interface ExpedienteTrackerProps {
  expediente: ExpedienteCliente;
  onVerPresupuestos: () => void;
}

const PASOS: { estado: EstadoExpediente; etiqueta: string; desc: string }[] = [
  { estado: 'RECEPCION', etiqueta: 'Recepción', desc: 'Ingreso e inventario del vehículo' },
  { estado: 'DIAGNOSTICO', etiqueta: 'Diagnosis', desc: 'Lectura OBD y peritaje mecánico' },
  { estado: 'EN_REPARACION', etiqueta: 'En Reparación', desc: 'Intervención activa en taller' },
  { estado: 'CONTROL_CALIDAD', etiqueta: 'Control Calidad', desc: 'Prueba en carretera y chequeo final' },
  { estado: 'LISTO', etiqueta: 'Listo para Entrega', desc: 'Vehículo higienizado a su disposición' }
];

const ordenEstados: Record<EstadoExpediente, number> = {
  'RECEPCION': 0,
  'DIAGNOSTICO': 1,
  'ESPERA_PIEZAS': 2,
  'EN_REPARACION': 2,
  'CONTROL_CALIDAD': 3,
  'LISTO': 4,
  'ENTREGADO': 5
};

export const ExpedienteTracker: React.FC<ExpedienteTrackerProps> = ({
  expediente,
  onVerPresupuestos
}) => {
  const pasoActual = ordenEstados[expediente.estado] ?? 0;
  const presupuestoPendiente = expediente.presupuestos.find(p => p.estado === 'PENDIENTE_FIRMA');

  return (
    <div className="bg-[#0e1424] border border-white/10 rounded-2xl p-6 lg:p-8 shadow-xl relative overflow-hidden">
      {/* Fondo decorativo con gradiente */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-sky-500/5 rounded-full blur-3xl pointer-events-none"></div>

      {/* Cabecera del Expediente */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="font-mono text-xs px-2.5 py-1 rounded bg-white/10 text-slate-300 font-bold">
              {expediente.codigoExpediente}
            </span>
            <span className="font-mono text-xs px-2.5 py-1 rounded bg-sky-500/15 text-sky-400 font-bold border border-sky-500/30">
              {expediente.matricula}
            </span>
            <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 font-semibold border border-emerald-500/30 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              {expediente.estado.replace('_', ' ')}
            </span>
          </div>

          <h2 className="text-2xl font-bold text-white tracking-tight">
            {expediente.marcaModelo}
          </h2>
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 mt-1">
            <span>Color: <strong className="text-slate-300">{expediente.color}</strong></span>
            <span>·</span>
            <span>Kilometraje: <strong className="text-slate-300">{expediente.kilometros.toLocaleString('es-ES')} km</strong></span>
            <span>·</span>
            <span>Recepción: <strong className="text-slate-300">{expediente.fechaEntrada}</strong></span>
          </div>
        </div>

        {/* Entrega estimada */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-3.5 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
              Entrega Estimada
            </div>
            <div className="text-sm font-bold text-white">
              {expediente.fechaEstimadaEntrega}
            </div>
          </div>
        </div>
      </div>

      {/* Alerta de Presupuesto Pendiente de Firma */}
      {presupuestoPendiente && (
        <div className="my-6 p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-amber-200">
                Presupuesto pendiente de aprobación ({presupuestoPendiente.numero})
              </div>
              <div className="text-xs text-amber-300/80">
                Importe total: <strong>{presupuestoPendiente.total.toFixed(2)} €</strong> (IVA incluido). Revisa y aprueba para continuar los trabajos.
              </div>
            </div>
          </div>
          <button
            onClick={onVerPresupuestos}
            className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-all shrink-0 cursor-pointer shadow-lg shadow-amber-500/20"
          >
            Revisar y Firmar Online
          </button>
        </div>
      )}

      {/* Barra y Stepper de Estados */}
      <div className="pt-6">
        <div className="flex items-center justify-between mb-2 text-xs">
          <span className="font-semibold text-slate-300">Progreso de la Intervención</span>
          <span className="font-bold text-sky-400 font-mono text-sm">{expediente.porcentajeProgreso}%</span>
        </div>

        {/* Barra de progreso */}
        <div className="w-full h-2.5 bg-white/5 rounded-full overflow-hidden mb-8 border border-white/5">
          <div
            className="h-full bg-gradient-to-r from-sky-500 via-indigo-500 to-purple-500 transition-all duration-700 ease-out"
            style={{ width: `${expediente.porcentajeProgreso}%` }}
          ></div>
        </div>

        {/* Pasos en Línea de Tiempo */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {PASOS.map((paso, idx) => {
            const isCompleted = idx < pasoActual;
            const isCurrent = idx === pasoActual;
            const isPending = idx > pasoActual;

            return (
              <div
                key={paso.estado}
                className={`p-3.5 rounded-xl border transition-all ${
                  isCurrent
                    ? 'bg-sky-500/10 border-sky-500/40 shadow-lg shadow-sky-500/10'
                    : isCompleted
                    ? 'bg-white/5 border-emerald-500/30'
                    : 'bg-white/[0.02] border-white/5 opacity-50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-mono text-slate-400">0{idx + 1}</span>
                  {isCompleted ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : isCurrent ? (
                    <Clock className="w-4 h-4 text-sky-400 animate-spin" />
                  ) : (
                    <span className="w-3 h-3 rounded-full border border-slate-600"></span>
                  )}
                </div>
                <div className="text-xs font-bold text-white mb-0.5">{paso.etiqueta}</div>
                <div className="text-[11px] text-slate-400 leading-tight">{paso.desc}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Trabajos en curso y Técnico responsable */}
      <div className="mt-8 pt-6 border-t border-white/10 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-3 flex items-center gap-1.5">
            <Wrench className="w-3.5 h-3.5 text-sky-400" />
            <span>Trabajos Incluidos en la Orden</span>
          </div>
          <ul className="space-y-2">
            {expediente.trabajosPrincipales.map((t, i) => (
              <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-sky-400 mt-1.5 shrink-0"></span>
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-xl p-4">
          <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-2 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-purple-400" />
            <span>Jefe de Taller / Técnico Asignado</span>
          </div>
          <div className="text-sm font-bold text-white">{expediente.mecanicoAsignado}</div>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Responsable técnico de supervisión y control pericial de tu vehículo en esta intervención.
          </p>
        </div>
      </div>
    </div>
  );
};
