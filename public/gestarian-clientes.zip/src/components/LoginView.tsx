import React, { useState } from 'react';
import { ArrowRight, ShieldCheck, Car, Key, Sparkles } from 'lucide-react';

interface LoginViewProps {
  onLogin: (dni: string, email: string) => void;
  error?: string | null;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLogin, error }) => {
  const [dni, setDni] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (dni.trim() && email.trim()) {
      onLogin(dni.trim(), email.trim());
    }
  };

  const handleDemoAccess = (demoDni: string, demoEmail: string) => {
    setDni(demoDni);
    setEmail(demoEmail);
    onLogin(demoDni, demoEmail);
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-white flex flex-col justify-between p-6 md:p-12 relative overflow-hidden font-sans">
      {/* Luces de fondo ambientación espaciada */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-purple-600/15 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-sky-500/15 rounded-full blur-[120px] pointer-events-none"></div>

      {/* Encabezado */}
      <header className="flex justify-between items-center relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-purple-600 flex items-center justify-center font-bold text-white text-sm shadow-lg shadow-sky-500/20">
            G
          </div>
          <span className="text-xs uppercase tracking-widest font-semibold text-slate-400">
            GESTARIAN · ÁREA DE CLIENTES
          </span>
        </div>
        <a
          href="https://gestarian-site.web.app"
          target="_blank"
          rel="noreferrer"
          className="text-xs text-slate-400 hover:text-white transition-colors"
        >
          Ir a Gestarian Site →
        </a>
      </header>

      {/* Formulario Central Big Typography */}
      <main className="max-w-lg w-full mx-auto my-auto py-12 relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/20 text-sky-400 text-xs font-semibold mb-6">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Acceso Directo Sin Contraseñas</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-light tracking-tight text-slate-100 leading-tight mb-4">
          Seguimiento en directo de <br />
          <strong className="font-semibold text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-sky-400">
            tu vehículo y expedientes
          </strong>
        </h1>

        <p className="text-slate-400 text-base font-light mb-8 leading-relaxed">
          Introduce tu DNI/CIF y correo electrónico para acceder al estado de la reparación, 
          fotos de cada fase y firma de presupuestos.
        </p>

        {error && (
          <div className="mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-2">
              DNI, NIE o CIF
            </label>
            <input
              type="text"
              placeholder="Ej: 12345678Z / B87654321"
              value={dni}
              onChange={(e) => setDni(e.target.value)}
              className="w-full text-lg p-4 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-sky-400 focus:bg-white/10 transition-all text-white placeholder-slate-500 font-mono"
              required
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-2">
              Correo Electrónico
            </label>
            <input
              type="email"
              placeholder="Ej: cliente@gestarian.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full text-lg p-4 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-sky-400 focus:bg-white/10 transition-all text-white placeholder-slate-500"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full mt-2 py-4 px-6 rounded-xl bg-gradient-to-r from-sky-500 to-purple-600 hover:from-sky-400 hover:to-purple-500 text-white font-semibold text-base transition-all shadow-lg shadow-sky-500/20 active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Acceder a mi Área Privada</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </form>

        {/* Accesos rápidos de Demostración */}
        <div className="mt-8 pt-6 border-t border-white/10">
          <div className="text-xs uppercase tracking-wider text-slate-500 font-semibold mb-3">
            O prueba con un expediente de demostración en 1 click:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => handleDemoAccess('12345678Z', 'cliente@gestarian.com')}
              className="p-3 text-left rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-sky-500/40 transition-all cursor-pointer group"
            >
              <div className="text-xs font-bold text-white group-hover:text-sky-400 transition-colors">
                🚗 DM Car · Mercedes C220d
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                DNI: 12345678Z (En Reparación)
              </div>
            </button>

            <button
              type="button"
              onClick={() => handleDemoAccess('A87654321', 'facturacion@soluciones-tec.com')}
              className="p-3 text-left rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-500/40 transition-all cursor-pointer group"
            >
              <div className="text-xs font-bold text-white group-hover:text-purple-400 transition-colors">
                🚐 Soluciones Tec · Renault Trafic
              </div>
              <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                CIF: A87654321 (Control Calidad)
              </div>
            </button>
          </div>
        </div>
      </main>

      {/* Pie de Página */}
      <footer className="text-slate-500 text-xs text-center relative z-10 pt-6 border-t border-white/5">
        &copy; 2026 GESTARIAN · Sistema Seguro de Acceso Documental para Clientes
      </footer>
    </div>
  );
};
