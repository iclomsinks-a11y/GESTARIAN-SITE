import React from 'react';
import { FotoEvolucion } from '../types';
import { X, Calendar, Clock, MessageSquare, Camera } from 'lucide-react';

interface ModalVisorFotoProps {
  foto: FotoEvolucion;
  onCerrar: () => void;
}

export const ModalVisorFoto: React.FC<ModalVisorFotoProps> = ({ foto, onCerrar }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-4xl w-full bg-[#0e1424] border border-white/10 rounded-2xl overflow-hidden shadow-2xl relative flex flex-col max-h-[90vh]">
        <button
          onClick={onCerrar}
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/90 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Imagen en grande */}
        <div className="relative flex-1 bg-black flex items-center justify-center min-h-[300px] overflow-hidden">
          <img
            src={foto.url}
            alt={foto.titulo}
            className="max-h-[60vh] w-auto max-w-full object-contain"
          />
          <div className="absolute top-4 left-4 px-3 py-1 rounded-md bg-black/60 backdrop-blur-md text-xs font-bold text-white border border-white/10">
            {foto.fase}
          </div>
        </div>

        {/* Detalles en pie de foto */}
        <div className="p-6 bg-[#0e1424] border-t border-white/10">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <h3 className="text-lg font-bold text-white">{foto.titulo}</h3>
            <div className="text-xs text-slate-400 flex items-center gap-3">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {foto.fecha}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {foto.hora}
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed mb-3">
            {foto.descripcion}
          </p>

          {foto.observacionesMecanico && (
            <div className="p-3 bg-white/5 border border-white/10 rounded-xl flex items-start gap-2 text-xs text-sky-200">
              <MessageSquare className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-sky-300 block mb-0.5">Nota técnica del mecánico:</strong>
                <span>{foto.observacionesMecanico}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
