import React from 'react';
import { FacturaCliente } from '../types';
import { Receipt, Download, CheckCircle2, Clock, FileCode } from 'lucide-react';

interface FacturasViewProps {
  facturas: FacturaCliente[];
  onDescargarFactura: (fac: FacturaCliente) => void;
}

export const FacturasView: React.FC<FacturasViewProps> = ({
  facturas,
  onDescargarFactura
}) => {
  if (facturas.length === 0) {
    return (
      <div className="bg-[#0e1424] border border-white/10 rounded-2xl p-8 text-center">
        <Receipt className="w-10 h-10 text-slate-500 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white mb-1">Sin facturas emitidas</h3>
        <p className="text-xs text-slate-400">
          Las facturas y justificantes de pago aparecerán en esta sección conforme se generen en el sistema.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Receipt className="w-5 h-5 text-emerald-400" />
          <span>Facturas Oficiales y Justificantes de Pago</span>
        </h3>
        <p className="text-xs text-slate-400">
          Documentos fiscales válidos para tu contabilidad o deducción tributaria. Disponibles para descarga permanente.
        </p>
      </div>

      <div className="space-y-3">
        {facturas.map((fac) => {
          const isPagada = fac.estadoPago === 'PAGADA';

          return (
            <div
              key={fac.id}
              className="bg-[#0e1424] border border-white/10 hover:border-white/20 rounded-2xl p-5 lg:p-6 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="flex items-start sm:items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                  isPagada
                    ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                    : 'bg-amber-500/10 border border-amber-500/20 text-amber-400'
                }`}>
                  <Receipt className="w-6 h-6" />
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="font-mono text-sm font-bold text-white">
                      {fac.numero}
                    </span>
                    <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full ${
                      isPagada
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                        : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                    }`}>
                      {isPagada ? 'Pagada' : 'Pendiente de Cobro'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 font-medium">
                    {fac.conceptoPrincipal}
                  </p>

                  <div className="text-[11px] text-slate-400 mt-1 flex flex-wrap items-center gap-3">
                    <span>Emisión: <strong className="text-slate-300">{fac.fechaEmision}</strong></span>
                    <span>·</span>
                    <span>Método: <strong className="text-slate-300">{fac.metodoPago}</strong></span>
                  </div>
                </div>
              </div>

              {/* Importe y Acciones */}
              <div className="flex items-center justify-between md:justify-end gap-6 pt-3 md:pt-0 border-t md:border-t-0 border-white/5">
                <div className="text-left md:text-right">
                  <div className="text-[11px] text-slate-400">Total Factura</div>
                  <div className="text-lg font-bold text-white font-mono">
                    {fac.total.toFixed(2)} €
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Base: {fac.baseImponible.toFixed(2)} € + IVA {fac.ivaImporte.toFixed(2)} €
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onDescargarFactura(fac)}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 hover:text-white transition-all cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
                    title="Descargar PDF"
                  >
                    <Download className="w-4 h-4" />
                    <span className="hidden sm:inline">PDF</span>
                  </button>

                  <button
                    onClick={() => alert(`Descargando FacturaE XML para la factura ${fac.numero}`)}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
                    title="Descargar FacturaE XML (AEAT)"
                  >
                    <FileCode className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
