import React from 'react';
import { ClienteSesion, ExpedienteCliente } from '../types';
import { Car, Phone, MessageSquare, LogOut, Download, ShieldCheck, ChevronDown } from 'lucide-react';

interface HeaderProps {
  cliente: ClienteSesion;
  expedienteActivo: ExpedienteCliente;
  onSelectExpediente: (exp: ExpedienteCliente) => void;
  onLogout: () => void;
  onOpenContacto: () => void;
  onOpenInstalar: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cliente,
  expedienteActivo,
  onSelectExpediente,
  onLogout,
  onOpenContacto,
  onOpenInstalar
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#090d16]/90 backdrop-blur-md border-b border-white/10 px-4 lg:px-8 py-3.5 transition-all">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
        {/* Logo & Badge */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-purple-600 flex items-center justify-center font-bold text-white shadow-lg shadow-sky-500/20">
            G
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-white text-base">GESTARIAN</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-400 border border-sky-500/30">
                Área Privada
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              {cliente.tallerAsignado.nombre}
            </p>
          </div>
        </div>

        {/* Selector de Vehículo si hay más de 1 */}
        {cliente.expedientes.length > 1 && (
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-xl">
            <Car className="w-4 h-4 text-sky-400" />
            <select
              value={expedienteActivo.id}
              onChange={(e) => {
                const found = cliente.expedientes.find(x => x.id === e.target.value);
                if (found) onSelectExpediente(found);
              }}
              className="bg-transparent text-xs font-semibold text-white focus:outline-none cursor-pointer"
            >
              {cliente.expedientes.map((exp) => (
                <option key={exp.id} value={exp.id} className="bg-slate-900 text-white">
                  {exp.matricula} · {exp.marcaModelo}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Acciones Rápidas de Contacto e Instalación */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onOpenInstalar}
            className="hidden sm:flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-300 hover:bg-purple-500/20 transition-all cursor-pointer"
            title="Instalar en tu móvil o escritorio"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Instalar App</span>
          </button>

          <button
            onClick={onOpenContacto}
            className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/20 transition-all cursor-pointer"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Taller</span>
          </button>

          {/* Perfil & Salir */}
          <div className="flex items-center gap-2 pl-2 border-l border-white/10">
            <div className="text-right hidden md:block">
              <div className="text-xs font-bold text-slate-200">{cliente.nombreRazonSocial}</div>
              <div className="text-[10px] text-slate-400 font-mono">{cliente.dni}</div>
            </div>
            <button
              onClick={onLogout}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-all cursor-pointer"
              title="Cerrar sesión"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
