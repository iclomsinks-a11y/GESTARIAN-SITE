import React, { useState, useEffect } from 'react';
import { 
  ClienteSesion, 
  ExpedienteCliente, 
  PresupuestoCliente, 
  FacturaCliente, 
  FotoEvolucion 
} from './types';
import { CLIENTES_DEMO, obtenerClientePorDniOEmail } from './mockData';
import { Header } from './components/Header';
import { LoginView } from './components/LoginView';
import { ExpedienteTracker } from './components/ExpedienteTracker';
import { GaleriaEvolucion } from './components/GaleriaEvolucion';
import { PresupuestosView } from './components/PresupuestosView';
import { FacturasView } from './components/FacturasView';
import { CitasView } from './components/CitasView';
import { ModalFirmaPresupuesto } from './components/ModalFirmaPresupuesto';
import { ModalVisorFoto } from './components/ModalVisorFoto';
import { ModalContacto } from './components/ModalContacto';
import { ModalInstalarPwa } from './components/ModalInstalarPwa';
import { 
  Car, 
  FileText, 
  Receipt, 
  Calendar, 
  Camera, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles,
  PhoneCall
} from 'lucide-react';

export default function App() {
  const [cliente, setCliente] = useState<ClienteSesion | null>(null);
  const [expedienteActivo, setExpedienteActivo] = useState<ExpedienteCliente | null>(null);
  const [tabActiva, setTabActiva] = useState<'SEGUIMIENTO' | 'PRESUPUESTOS' | 'FACTURAS' | 'CITAS'>('SEGUIMIENTO');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [notificacion, setNotificacion] = useState<string | null>(null);

  // Modales
  const [presupuestoAFirmar, setPresupuestoAFirmar] = useState<PresupuestoCliente | null>(null);
  const [fotoEnVisor, setFotoEnVisor] = useState<FotoEvolucion | null>(null);
  const [isContactoOpen, setIsContactoOpen] = useState(false);
  const [isInstalarOpen, setIsInstalarOpen] = useState(false);

  // Inicialización: auto-login por query params o localStorage
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const dniParam = params.get('dni') || params.get('cif') || params.get('d');
    const emailParam = params.get('email') || params.get('e');

    if (dniParam) {
      const sesion = obtenerClientePorDniOEmail(dniParam, emailParam || undefined);
      if (sesion) {
        activarSesion(sesion);
        return;
      }
    }

    const saved = localStorage.getItem('gestarian_cliente_portal_session');
    if (saved) {
      try {
        const parsed: ClienteSesion = JSON.parse(saved);
        activarSesion(parsed);
      } catch (e) {
        console.warn('Error parseando sesion:', e);
      }
    }
  }, []);

  const activarSesion = (sesion: ClienteSesion) => {
    // Restaurar posibles modificaciones previas guardadas en localStorage
    const storedState = localStorage.getItem(`gestarian_expedientes_${sesion.dni}`);
    let expedientesActualizados = sesion.expedientes;

    if (storedState) {
      try {
        expedientesActualizados = JSON.parse(storedState);
      } catch (e) {
        console.warn('Error leyendo expedientes guardados:', e);
      }
    }

    const sesionCompleta = { ...sesion, expedientes: expedientesActualizados };
    setCliente(sesionCompleta);
    setExpedienteActivo(expedientesActualizados[0] || null);
    localStorage.setItem('gestarian_cliente_portal_session', JSON.stringify(sesionCompleta));
    setLoginError(null);
  };

  const handleLogin = (dniInput: string, emailInput: string) => {
    const sesion = obtenerClientePorDniOEmail(dniInput, emailInput);
    if (!sesion) {
      setLoginError('No se encontró ningún expediente activo para los datos introducidos.');
      return;
    }
    activarSesion(sesion);
    showNotice(`¡Bienvenido de nuevo, ${sesion.nombreRazonSocial.split(' ')[0]}!`);
  };

  const handleLogout = () => {
    setCliente(null);
    setExpedienteActivo(null);
    localStorage.removeItem('gestarian_cliente_portal_session');
    showNotice('Sesión cerrada correctamente.');
  };

  const showNotice = (msg: string) => {
    setNotificacion(msg);
    setTimeout(() => {
      setNotificacion(null);
    }, 4500);
  };

  // Manejador de confirmación de firma de presupuesto
  const handleConfirmarFirmaPresupuesto = (presupuestoId: string, firmaHash: string) => {
    if (!cliente || !expedienteActivo) return;

    const fechaAhora = new Date().toLocaleString('es-ES');
    const nuevosPresupuestos = expedienteActivo.presupuestos.map(p => {
      if (p.id === presupuestoId) {
        return {
          ...p,
          estado: 'APROBADO' as const,
          fechaAprobacion: fechaAhora,
          firmaHash,
          firmanteNombre: cliente.nombreRazonSocial,
          firmanteDni: cliente.dni
        };
      }
      return p;
    });

    const expedienteModificado = {
      ...expedienteActivo,
      presupuestos: nuevosPresupuestos,
      porcentajeProgreso: Math.max(expedienteActivo.porcentajeProgreso, 50)
    };

    const nuevosExpedientes = cliente.expedientes.map(exp => 
      exp.id === expedienteActivo.id ? expedienteModificado : exp
    );

    const nuevoCliente = { ...cliente, expedientes: nuevosExpedientes };
    setCliente(nuevoCliente);
    setExpedienteActivo(expedienteModificado);
    localStorage.setItem(`gestarian_expedientes_${cliente.dni}`, JSON.stringify(nuevosExpedientes));
    localStorage.setItem('gestarian_cliente_portal_session', JSON.stringify(nuevoCliente));

    setPresupuestoAFirmar(null);
    showNotice(`✅ Presupuesto aprobado y sellado telemáticamente con éxito. Referencia de firma: ${firmaHash}`);
  };

  const handleDescargarPdf = (presupuesto: PresupuestoCliente) => {
    window.print();
  };

  const handleDescargarFactura = (factura: FacturaCliente) => {
    window.print();
  };

  const handleSolicitudCitaEnviada = (servicio: string, fecha: string) => {
    showNotice(`📅 Solicitud de cita para "${servicio}" recibida para el ${fecha}. Te contactaremos de inmediato.`);
  };

  if (!cliente || !expedienteActivo) {
    return <LoginView onLogin={handleLogin} error={loginError} />;
  }

  const presupuestosPendientesCount = expedienteActivo.presupuestos.filter(p => p.estado === 'PENDIENTE_FIRMA').length;

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-purple-500 selection:text-white">
      {/* Notificación Toast Flotante */}
      {notificacion && (
        <div className="fixed top-20 right-4 z-50 max-w-md bg-emerald-500/90 backdrop-blur-md text-slate-950 font-bold px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-fade-in border border-emerald-400">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span className="text-xs">{notificacion}</span>
        </div>
      )}

      {/* Cabecera Principal */}
      <Header
        cliente={cliente}
        expedienteActivo={expedienteActivo}
        onSelectExpediente={setExpedienteActivo}
        onLogout={handleLogout}
        onOpenContacto={() => setIsContactoOpen(true)}
        onOpenInstalar={() => setIsInstalarOpen(true)}
      />

      {/* Navegación por Pestañas */}
      <nav className="bg-[#0b0f19] border-b border-white/5 sticky top-[61px] z-30">
        <div className="max-w-7xl mx-auto px-4 lg:px-8 flex items-center gap-2 overflow-x-auto py-2.5">
          <button
            onClick={() => setTabActiva('SEGUIMIENTO')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
              tabActiva === 'SEGUIMIENTO'
                ? 'bg-sky-500/15 text-sky-400 border border-sky-500/30 shadow-lg shadow-sky-500/10'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Car className="w-4 h-4" />
            <span>Estado & Evolución ({expedienteActivo.matricula})</span>
          </button>

          <button
            onClick={() => setTabActiva('PRESUPUESTOS')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shrink-0 cursor-pointer relative ${
              tabActiva === 'PRESUPUESTOS'
                ? 'bg-sky-500/15 text-sky-400 border border-sky-500/30 shadow-lg shadow-sky-500/10'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Presupuestos</span>
            {presupuestosPendientesCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px] flex items-center justify-center animate-pulse">
                {presupuestosPendientesCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setTabActiva('FACTURAS')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
              tabActiva === 'FACTURAS'
                ? 'bg-sky-500/15 text-sky-400 border border-sky-500/30 shadow-lg shadow-sky-500/10'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Facturas y Recibos</span>
          </button>

          <button
            onClick={() => setTabActiva('CITAS')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
              tabActiva === 'CITAS'
                ? 'bg-sky-500/15 text-sky-400 border border-sky-500/30 shadow-lg shadow-sky-500/10'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Pedir Cita</span>
          </button>
        </div>
      </nav>

      {/* Contenido Principal según Pestaña */}
      <main className="max-w-7xl mx-auto px-4 lg:px-8 py-8 flex-1 w-full space-y-8">
        {tabActiva === 'SEGUIMIENTO' && (
          <>
            <ExpedienteTracker
              expediente={expedienteActivo}
              onVerPresupuestos={() => setTabActiva('PRESUPUESTOS')}
            />

            <GaleriaEvolucion
              fotos={expedienteActivo.fotosEvolucion}
              onSeleccionarFoto={setFotoEnVisor}
            />
          </>
        )}

        {tabActiva === 'PRESUPUESTOS' && (
          <PresupuestosView
            presupuestos={expedienteActivo.presupuestos}
            onAbrirFirma={setPresupuestoAFirmar}
            onDescargarPdf={handleDescargarPdf}
          />
        )}

        {tabActiva === 'FACTURAS' && (
          <FacturasView
            facturas={expedienteActivo.facturas}
            onDescargarFactura={handleDescargarFactura}
          />
        )}

        {tabActiva === 'CITAS' && (
          <CitasView
            matricula={expedienteActivo.matricula}
            marcaModelo={expedienteActivo.marcaModelo}
            onSolicitudEnviada={handleSolicitudCitaEnviada}
          />
        )}
      </main>

      {/* Pie de página */}
      <footer className="border-t border-white/5 bg-[#080c14] py-6 px-4 lg:px-8 text-center text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-400">GESTARIAN</span>
            <span>· Portal Oficial del Cliente</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Taller: {cliente.tallerAsignado.nombre}</span>
            <span>·</span>
            <span>CIF: {cliente.tallerAsignado.cif}</span>
          </div>
        </div>
      </footer>

      {/* Modales Flotantes */}
      {presupuestoAFirmar && (
        <ModalFirmaPresupuesto
          presupuesto={presupuestoAFirmar}
          cliente={cliente}
          onConfirmar={handleConfirmarFirmaPresupuesto}
          onCerrar={() => setPresupuestoAFirmar(null)}
        />
      )}

      {fotoEnVisor && (
        <ModalVisorFoto
          foto={fotoEnVisor}
          onCerrar={() => setFotoEnVisor(null)}
        />
      )}

      {isContactoOpen && (
        <ModalContacto
          taller={cliente.tallerAsignado}
          matricula={expedienteActivo.matricula}
          onCerrar={() => setIsContactoOpen(false)}
        />
      )}

      {isInstalarOpen && (
        <ModalInstalarPwa
          onCerrar={() => setIsInstalarOpen(false)}
        />
      )}
    </div>
  );
}
