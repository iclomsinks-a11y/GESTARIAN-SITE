import { ClienteSesion } from './types';

export const CLIENTES_DEMO: Record<string, ClienteSesion> = {
  '12345678Z': {
    dni: '12345678Z',
    email: 'cliente@gestarian.com',
    nombreRazonSocial: 'David Martínez (DM Car)',
    telefono: '+34 622 11 22 33',
    direccion: 'Av. Diagonal 450, 2ºB, Barcelona',
    tallerAsignado: {
      nombre: 'Talleres Mecánicos Gestarian Pro',
      cif: 'B-87654321',
      direccion: 'Polígono Industrial Las Mercedes, Nave 14, Madrid',
      telefono: '+34 912 345 678',
      whatsapp: '34622112233',
      email: 'recepcion@talleresgestarian.com'
    },
    expedientes: [
      {
        id: 'exp-1',
        codigoExpediente: 'EXP-2026-089',
        matricula: '8492-LZB',
        marcaModelo: 'Mercedes-Benz C220d AMG Line (W205)',
        kilometros: 142350,
        color: 'Gris Selenita Metalizado',
        anoFabricacion: 2020,
        fechaEntrada: '07/10/2026',
        fechaEstimadaEntrega: '11/10/2026 - 18:30h',
        estado: 'EN_REPARACION',
        porcentajeProgreso: 65,
        mecanicoAsignado: 'Carlos Morales (Jefe de Taller)',
        trabajosPrincipales: [
          'Sustitución kit distribución y bomba de agua',
          'Cambio discos y pastillas delanteras cerámicas',
          'Revisión electrónica y purgado de circuito de frenos',
          'Diagnosis completa motor Star Diagnosis'
        ],
        fotosEvolucion: [
          {
            id: 'foto-1',
            titulo: 'Recepción e Inspección Pericial',
            fase: '1. Recepción',
            fecha: '07/10/2026',
            hora: '09:15',
            url: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=1000&q=80',
            descripcion: 'Vehículo recibido en bahía pericial. Comprobación de kilometraje y estado exterior de carrocería.',
            observacionesMecanico: 'Desgaste pronunciado detectado en discos delanteros. Sin golpes estructurales.'
          },
          {
            id: 'foto-2',
            titulo: 'Desmontaje y Acceso a Conjunto Distribución',
            fase: '2. En Reparación',
            fecha: '08/10/2026',
            hora: '11:40',
            url: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=1000&q=80',
            descripcion: 'Retirada de frontal, radiador y correas auxiliares. Acceso directo a rodillos tensores.',
            observacionesMecanico: 'Rodillo tensor con leve holgura. Sustituido por componente original Mercedes OE.'
          },
          {
            id: 'foto-3',
            titulo: 'Instalación de Kit de Frenos y Calibración',
            fase: '3. En Reparación',
            fecha: '09/10/2026',
            hora: '10:20',
            url: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1000&q=80',
            descripcion: 'Discos ventilados montados con dinamométrica a 115 Nm. Sensores de desgaste renovados.',
            observacionesMecanico: 'Purgado neumático completado. Pruebas de mordida en banco de rodillos superadas.'
          }
        ],
        presupuestos: [
          {
            id: 'pre-1',
            numero: 'PRE-2026-041',
            fecha: '07/10/2026',
            validoHasta: '22/10/2026',
            estado: 'PENDIENTE_FIRMA',
            conceptos: [
              { id: 'c-1', descripcion: 'Kit de distribución completo reforzado con bomba de agua (OEM)', cantidad: 1, precioUnitario: 345.00, total: 345.00, tipo: 'RECAMBIO' },
              { id: 'c-2', descripcion: 'Líquido refrigerante orgánico Mercedes G40 (5L)', cantidad: 2, precioUnitario: 22.50, total: 45.00, tipo: 'RECAMBIO' },
              { id: 'c-3', descripcion: 'Juego discos de freno delanteros perforados 330mm', cantidad: 1, precioUnitario: 210.00, total: 210.00, tipo: 'RECAMBIO' },
              { id: 'c-4', descripcion: 'Juego pastillas de freno cerámicas + testigos', cantidad: 1, precioUnitario: 95.00, total: 95.00, tipo: 'RECAMBIO' },
              { id: 'c-5', descripcion: 'Mano de obra especializada (distribución y frenos)', cantidad: 4.5, precioUnitario: 55.00, total: 247.50, tipo: 'MANO_OBRA' },
              { id: 'c-6', descripcion: 'Gestión medioambiental y reciclaje RAEE', cantidad: 1, precioUnitario: 8.50, total: 8.50, tipo: 'GESTION' }
            ],
            baseImponible: 951.00,
            ivaPorcentaje: 21,
            ivaImporte: 199.71,
            total: 1150.71
          }
        ],
        facturas: [
          {
            id: 'fac-ant',
            numero: 'FAC-2026-018-A',
            fechaEmision: '07/10/2026',
            fechaVencimiento: '07/10/2026',
            estadoPago: 'PAGADA',
            metodoPago: 'Tarjeta Bancaria / TPV',
            baseImponible: 250.00,
            ivaPorcentaje: 21,
            ivaImporte: 52.50,
            total: 302.50,
            conceptoPrincipal: 'Anticipo 30% orden de reparación EXP-2026-089'
          }
        ]
      },
      {
        id: 'exp-2',
        codigoExpediente: 'EXP-2025-142',
        matricula: '5123-KJH',
        marcaModelo: 'Audi A4 Avant 2.0 TDI S-tronic',
        kilometros: 189200,
        color: 'Negro Mitos Efecto Perla',
        anoFabricacion: 2018,
        fechaEntrada: '14/11/2025',
        fechaEstimadaEntrega: '16/11/2025',
        estado: 'ENTREGADO',
        porcentajeProgreso: 100,
        mecanicoAsignado: 'Pedro Santillana',
        trabajosPrincipales: [
          'Mantenimiento mayor 180.000km con aceite Castrol 5W30',
          'Sustitución de todos los filtros (aceite, aire, habitáculo y combustible)',
          'Chequeo pre-ITV e informe de emisiones favorable'
        ],
        fotosEvolucion: [
          {
            id: 'foto-audi-1',
            titulo: 'Revisión final y lavado de cortesía',
            fase: 'Entrega final',
            fecha: '16/11/2025',
            hora: '17:00',
            url: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=1000&q=80',
            descripcion: 'Vehículo lavado e higienizado listo para entrega.',
            observacionesMecanico: 'ITV superada sin defectos. Presiones ajustadas a 2.4 bar.'
          }
        ],
        presupuestos: [
          {
            id: 'pre-audi-1',
            numero: 'PRE-2025-210',
            fecha: '14/11/2025',
            validoHasta: '14/12/2025',
            estado: 'APROBADO',
            fechaAprobacion: '14/11/2025 10:14',
            firmaHash: 'GEST-FIRMA-8849-AF01',
            firmanteNombre: 'David Martínez',
            firmanteDni: '12345678Z',
            conceptos: [
              { id: 'ca-1', descripcion: 'Aceite LongLife III FE 0W-30 (5L)', cantidad: 1, precioUnitario: 78.00, total: 78.00, tipo: 'RECAMBIO' },
              { id: 'ca-2', descripcion: 'Pack 4 Filtros Mann Filter OE', cantidad: 1, precioUnitario: 94.00, total: 94.00, tipo: 'RECAMBIO' },
              { id: 'ca-3', descripcion: 'Mano de obra servicio de mantenimiento y diagnosis', cantidad: 2.0, precioUnitario: 55.00, total: 110.00, tipo: 'MANO_OBRA' }
            ],
            baseImponible: 282.00,
            ivaPorcentaje: 21,
            ivaImporte: 59.22,
            total: 341.22
          }
        ],
        facturas: [
          {
            id: 'fac-audi-final',
            numero: 'FAC-2025-098',
            fechaEmision: '16/11/2025',
            fechaVencimiento: '16/11/2025',
            estadoPago: 'PAGADA',
            metodoPago: 'Transferencia Bancaria SEPA',
            baseImponible: 282.00,
            ivaPorcentaje: 21,
            ivaImporte: 59.22,
            total: 341.22,
            conceptoPrincipal: 'Mantenimiento completo 180.000km Audi A4 5123-KJH'
          }
        ]
      }
    ]
  },
  'A87654321': {
    dni: 'A87654321',
    email: 'facturacion@soluciones-tec.com',
    nombreRazonSocial: 'Soluciones Tecnológicas S.A.',
    telefono: '+34 913 88 99 00',
    direccion: 'Paseo de la Castellana 210, Planta 8, Madrid',
    tallerAsignado: {
      nombre: 'Talleres Mecánicos Gestarian Pro',
      cif: 'B-87654321',
      direccion: 'Polígono Industrial Las Mercedes, Nave 14, Madrid',
      telefono: '+34 912 345 678',
      whatsapp: '34622112233',
      email: 'flotas@talleresgestarian.com'
    },
    expedientes: [
      {
        id: 'exp-flota-1',
        codigoExpediente: 'EXP-2026-104',
        matricula: '1042-MBK',
        marcaModelo: 'Renault Trafic L2H1 dCi 150cv (Flota Comercial)',
        kilometros: 98400,
        color: 'Blanco Glaciar',
        anoFabricacion: 2022,
        fechaEntrada: '08/10/2026',
        fechaEstimadaEntrega: '10/10/2026 - 12:00h',
        estado: 'CONTROL_CALIDAD',
        porcentajeProgreso: 90,
        mecanicoAsignado: 'Mateo Beltrán',
        trabajosPrincipales: [
          'Cambio embrague bimasa y collarín hidráulico',
          'Alineación y paralelo de dirección por láser',
          'Sustitución de neumáticos delanteros Michelin Agilis 3'
        ],
        fotosEvolucion: [
          {
            id: 'foto-flota-1',
            titulo: 'Revisión en Elevador de Carga',
            fase: 'Diagnosis',
            fecha: '08/10/2026',
            hora: '08:45',
            url: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=1000&q=80',
            descripcion: 'Inspección de caja de cambios y holgura en pedal de embrague.',
            observacionesMecanico: 'Embrague patinando por desgaste de disco. Requiere sustitución bimasa.'
          }
        ],
        presupuestos: [
          {
            id: 'pre-flota-1',
            numero: 'PRE-2026-068',
            fecha: '08/10/2026',
            validoHasta: '23/10/2026',
            estado: 'APROBADO',
            fechaAprobacion: '08/10/2026 11:30',
            firmaHash: 'GEST-FIRMA-TECH-901',
            firmanteNombre: 'Soluciones Tecnológicas S.A.',
            firmanteDni: 'A87654321',
            conceptos: [
              { id: 'cf-1', descripcion: 'Kit Embrague Bimasa Valeo OE Renault', cantidad: 1, precioUnitario: 620.00, total: 620.00, tipo: 'RECAMBIO' },
              { id: 'cf-2', descripcion: '2x Neumáticos Michelin Agilis 3 215/65 R16C', cantidad: 2, precioUnitario: 145.00, total: 290.00, tipo: 'RECAMBIO' },
              { id: 'cf-3', descripcion: 'Mano de obra y montaje de transmisión', cantidad: 5.0, precioUnitario: 52.00, total: 260.00, tipo: 'MANO_OBRA' }
            ],
            baseImponible: 1170.00,
            ivaPorcentaje: 21,
            ivaImporte: 245.70,
            total: 1415.70
          }
        ],
        facturas: [
          {
            id: 'fac-flota-1',
            numero: 'FAC-2026-031',
            fechaEmision: '09/10/2026',
            fechaVencimiento: '24/10/2026',
            estadoPago: 'PENDIENTE',
            metodoPago: 'Recibo Domiciliado (SEPA B2B)',
            baseImponible: 1170.00,
            ivaPorcentaje: 21,
            ivaImporte: 245.70,
            total: 1415.70,
            conceptoPrincipal: 'Sustitución embrague y neumáticos Renault Trafic 1042-MBK'
          }
        ]
      }
    ]
  }
};

export function obtenerClientePorDniOEmail(dniInput: string, emailInput?: string): ClienteSesion | null {
  const cleanDni = dniInput.replace(/[\s\-_.]/g, '').toUpperCase().trim();
  const cleanEmail = (emailInput || '').trim().toLowerCase();

  // Buscar coincidencia exacta por DNI o Email
  if (CLIENTES_DEMO[cleanDni]) {
    return CLIENTES_DEMO[cleanDni];
  }

  for (const client of Object.values(CLIENTES_DEMO)) {
    if (client.email.toLowerCase() === cleanEmail) {
      return client;
    }
  }

  // Generar sesión por defecto limpia si el usuario entra con su propio DNI/Email
  if (cleanDni.length >= 5) {
    return {
      dni: cleanDni,
      email: cleanEmail || `${cleanDni.toLowerCase()}@cliente.es`,
      nombreRazonSocial: `Cliente Registrado (${cleanDni})`,
      telefono: '+34 600 000 000',
      direccion: 'España',
      tallerAsignado: {
        nombre: 'Talleres Mecánicos Gestarian Pro',
        cif: 'B-87654321',
        direccion: 'Polígono Industrial Las Mercedes, Nave 14, Madrid',
        telefono: '+34 912 345 678',
        whatsapp: '34622112233',
        email: 'recepcion@talleresgestarian.com'
      },
      expedientes: [
        {
          id: `exp-${Date.now()}`,
          codigoExpediente: `EXP-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
          matricula: 'PENDIENTE',
          marcaModelo: 'Vehículo en Recepción',
          kilometros: 0,
          color: 'Blanco',
          fechaEntrada: new Date().toLocaleDateString('es-ES'),
          fechaEstimadaEntrega: 'En valoración',
          estado: 'RECEPCION',
          porcentajeProgreso: 15,
          mecanicoAsignado: 'Equipo de Recepción Técnica',
          trabajosPrincipales: ['Apertura de orden de trabajo y recepción de llaves'],
          fotosEvolucion: [],
          presupuestos: [],
          facturas: []
        }
      ]
    };
  }

  return null;
}
