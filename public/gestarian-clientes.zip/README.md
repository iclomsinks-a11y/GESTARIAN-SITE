# 🛰️ GESTARIAN · Portal del Cliente (Área Privada de Clientes)

Portal seguro y autónomo para clientes de talleres, servicios técnicos y empresas usuarias del ecosistema **GESTARIAN**. 
Permite el seguimiento en tiempo real de intervenciones mecánicas, aprobación telemática de presupuestos y descarga directa de facturas oficiales.

---

## 🌟 Características Principales

1. **Acceso Seguro sin Contraseñas:**
   - Autenticación mediante **DNI / NIE / CIF** y correo electrónico.
   - Enlace directo / acceso mágico mediante parámetros de URL (`?dni=12345678Z&email=cliente@gestarian.com`) enviados automáticamente por WhatsApp o Email desde Gestarian Pro.

2. **Seguimiento del Vehículo en Tiempo Real:**
   - Línea de tiempo interactiva con las 5 fases de taller:
     1. Recepción & Peritaje
     2. Diagnosis
     3. En Reparación / Intervención
     4. Control de Calidad
     5. Listo para Entrega
   - Porcentaje de avance de la reparación y fecha estimada de entrega.

3. **Evolución Audiovisual (Fotos Periciales):**
   - Galería de fotos con fecha, hora y notas técnicas subidas por el jefe de taller durante la reparación.
   - Visor fotográfico con zoom para máxima transparencia con el cliente.

4. **Presupuestos y Firma Digital Telemática:**
   - Desglose exhaustivo de piezas, recambios originales (OEM) y horas de mano de obra.
   - **Lienzo de firma táctil y digital** para aprobación telemática en 1 clic.
   - Generación de hash criptográfico de conformidad y descarga oficial en PDF.

5. **Facturas y Justificantes:**
   - Consulta de facturas emitidas y estado de cobro.
   - Descarga en PDF oficial y formato FacturaE (AEAT).

6. **Citas y Contacto Directo:**
   - Solicitud de cita previa para mantenimiento o ITV.
   - Botón directo para chat de WhatsApp con el jefe de taller y localización en Google Maps.

7. **PWA (Progressive Web App):**
   - Instalable en pantalla de inicio de iPhone (Safari), Android (Chrome) y Escritorio (Windows / Mac).

---

## 🚀 Puesta en Marcha

```bash
# Instalar dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev

# Compilar para producción
npm run build
```

---

## 🔗 Conexión con el Ecosistema GESTARIAN

- **Suite Principal:** `https://github.com/iclomsinks-a11y/GESTARIAN-SITE.git`
- **Landing Page:** `https://github.com/iclomsinks-a11y/landing-page.git`
- **Portal de Clientes:** `https://github.com/iclomsinks-a11y/GESTAIRAN-CLIENTES.git`

&copy; 2026 GESTARIAN. Todos los derechos reservados.
